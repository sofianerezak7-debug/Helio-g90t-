# Redmi Note 8 Pro / Helio G90T compatibility patch

Changes in this source archive:
- Default internal resolution changed to 480p.
- Default frame-rate target changed to 30 FPS.
- Recommended graphics preset explicitly returns Minimum for MT6785/G90T/K79V1_64 identifiers.
- For that device profile only, disables the newer native render-into-texture and native post-processing shortcuts in the emitted game config. This is a conservative diagnostic fallback, not a guaranteed crash fix.
- Keep the Android system Vulkan driver. Turnip is an Adreno driver and is not suitable for Mali-G76.

No APK was built or tested on a physical Redmi Note 8 Pro. The project still requires its documented external source dependencies and legally owned game files/code generation inputs to build.

If the app still crashes, export the app logs and inspect the first fatal/native crash entry before making further renderer changes.
