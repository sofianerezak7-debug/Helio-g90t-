package com.dfdx047.dragonburst

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.dfdx047.dragonburst.ui.LauncherApp
import com.dfdx047.dragonburst.ui.LauncherViewModel
import com.dfdx047.dragonburst.ui.theme.DragonBurstTheme

/**
 * Launcher Dragon Burst (Jetpack Compose). AppCompatActivity por causa do idioma
 * por app (pt/en) tambem em Android 11 e 12.
 */
class LauncherActivity : AppCompatActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            DragonBurstTheme(themeMode = vm.themeMode, darkMode = vm.darkMode) {
                LauncherApp(vm)
            }
        }
        vm.checkUpdatesOnLaunch()
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar do jogo: o menu rapido pode ter mudado opcoes e ha log novo.
        vm.reloadAfterGame()
    }
}
